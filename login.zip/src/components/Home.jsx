import React from "react";
import { useNavigate } from "react-router-dom";

function Home() {
  const navigate = useNavigate();

  const handleLogout = () => {
    // Handle logout logic
    navigate("/signup"); // Navigate to /signup after logout
  };

  return (
    <>
      <h1>Welcome to the Home Page</h1>
      <button onClick={handleLogout}>Logout</button>
    </>
  );
}

export default Home;